// Design tokens ported from src/index.css of the web prototype.
export const colors = {
  cream: "#fffaf4",
  paper: "#fffdf9",
  ink: "#473843",
  muted: "#8c7b86",
  placeholder: "#b9adb3",
  pink: "#e98fac",
  pinkSoft: "#fbe1e9",
  pinkPale: "#fff0f4",
  lavender: "#a89ad1",
  lavenderSoft: "#eee9fa",
  sage: "#91b79a",
  sageSoft: "#e8f2e6",
  sageInk: "#648e6e",
  peach: "#efb495",
  peachSoft: "#fae7da",
  line: "#ede4e4",
  white: "#ffffff",
  danger: "#d2657f",
  dangerSoft: "#fdeaee",
  outline: "#765e6b",
};

export const fonts = {
  heading: "Nunito_800ExtraBold",
  headingSemi: "Nunito_700Bold",
  body: "DMSans_400Regular",
  bodyMedium: "DMSans_500Medium",
  bodyBold: "DMSans_700Bold",
  hand: "Gaegu_700Bold",
};

export const shadow = {
  shadowColor: "#6d4e5e",
  shadowOffset: { width: 0, height: 8 },
  shadowOpacity: 0.09,
  shadowRadius: 24,
  elevation: 3,
};

export const shadowSmall = {
  shadowColor: "#6d4e5e",
  shadowOffset: { width: 0, height: 4 },
  shadowOpacity: 0.07,
  shadowRadius: 12,
  elevation: 2,
};
