import { useState } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View, type TextInputProps } from "react-native";
import Icon, { type IconName } from "./Icon";
import { colors, fonts } from "../theme";

type Props = TextInputProps & {
  label: string;
  icon: IconName;
  error?: string;
  secure?: boolean; // shows a show/hide toggle
};

export default function AuthField({ label, icon, error, secure, style, ...inputProps }: Props) {
  const [focused, setFocused] = useState(false);
  const [hidden, setHidden] = useState(true);

  return (
    <View style={styles.group}>
      <Text style={styles.label}>{label}</Text>
      <View style={[styles.shell, focused && styles.focused, !!error && styles.errored]}>
        <Icon name={icon} size={18} color={focused ? colors.pink : colors.muted} />
        <TextInput
          {...inputProps}
          style={[styles.input, style]}
          placeholderTextColor={colors.placeholder}
          secureTextEntry={secure ? hidden : inputProps.secureTextEntry}
          onFocus={(e) => { setFocused(true); inputProps.onFocus?.(e); }}
          onBlur={(e) => { setFocused(false); inputProps.onBlur?.(e); }}
        />
        {secure && (
          <TouchableOpacity onPress={() => setHidden((h) => !h)} hitSlop={10} accessibilityLabel={hidden ? "Show password" : "Hide password"}>
            <Icon name={hidden ? "eye" : "eyeOff"} size={18} color={colors.muted} />
          </TouchableOpacity>
        )}
      </View>
      {!!error && <Text style={styles.error}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  group: { gap: 7 },
  label: { color: colors.muted, fontFamily: fonts.bodyBold, fontSize: 10, letterSpacing: 1.2 },
  shell: {
    flexDirection: "row", alignItems: "center", gap: 10, height: 52, paddingHorizontal: 14,
    borderRadius: 16, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.white,
  },
  focused: { borderColor: colors.pink, backgroundColor: colors.paper },
  errored: { borderColor: colors.danger },
  input: { flex: 1, height: "100%", color: colors.ink, fontFamily: fonts.body, fontSize: 14 },
  error: { color: colors.danger, fontFamily: fonts.bodyMedium, fontSize: 11 },
});
