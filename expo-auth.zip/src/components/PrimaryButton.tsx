import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import Icon, { type IconName } from "./Icon";
import { colors, fonts } from "../theme";

type Props = { title: string; onPress: () => void; loading?: boolean; disabled?: boolean; icon?: IconName };

export default function PrimaryButton({ title, onPress, loading, disabled, icon = "arrow" }: Props) {
  const inactive = disabled || loading;
  return (
    <TouchableOpacity activeOpacity={0.85} onPress={onPress} disabled={inactive} style={[styles.button, inactive && styles.inactive]}>
      {loading ? (
        <ActivityIndicator color={colors.white} />
      ) : (
        <View style={styles.row}>
          <Text style={styles.text}>{title}</Text>
          <Icon name={icon} size={18} color={colors.white} />
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    height: 54, alignItems: "center", justifyContent: "center", borderRadius: 17, backgroundColor: colors.pink,
    shadowColor: colors.pink, shadowOffset: { width: 0, height: 7 }, shadowOpacity: 0.24, shadowRadius: 15, elevation: 4,
  },
  inactive: { opacity: 0.55 },
  row: { flexDirection: "row", alignItems: "center", gap: 9 },
  text: { color: colors.white, fontFamily: fonts.bodyBold, fontSize: 14 },
});
