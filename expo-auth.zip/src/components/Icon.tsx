import Svg, { Circle, Path, Rect } from "react-native-svg";
import { colors } from "../theme";

export type IconName = "user" | "mail" | "lock" | "eye" | "eyeOff" | "sparkle" | "heart" | "check" | "arrow" | "back";

type Props = { name: IconName; size?: number; color?: string };

export default function Icon({ name, size = 20, color = colors.ink }: Props) {
  const p = { stroke: color, strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, fill: "none" };
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      {name === "user" && (<><Circle cx="12" cy="8" r="4" {...p} /><Path d="M4 22c0-5 3-8 8-8s8 3 8 8" {...p} /></>)}
      {name === "mail" && (<><Rect x="3" y="5" width="18" height="14" rx="3" {...p} /><Path d="m4 8 8 6 8-6" {...p} /></>)}
      {name === "lock" && (<><Rect x="5" y="11" width="14" height="10" rx="3" {...p} /><Path d="M8 11V8a4 4 0 0 1 8 0v3" {...p} /></>)}
      {name === "eye" && (<><Path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" {...p} /><Circle cx="12" cy="12" r="3" {...p} /></>)}
      {name === "eyeOff" && (<><Path d="M2 12s3.5-7 10-7c2 0 3.7.6 5.2 1.5M22 12s-3.5 7-10 7c-2 0-3.7-.6-5.2-1.5" {...p} /><Path d="m4 4 16 16" {...p} /></>)}
      {name === "sparkle" && (<><Path d="m12 2 1.5 5.5L19 9l-5.5 1.5L12 16l-1.5-5.5L5 9l5.5-1.5Z" {...p} /><Path d="m19 16 .7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7Z" {...p} /></>)}
      {name === "heart" && <Path d="M20.8 5.8a5.5 5.5 0 0 0-7.8 0L12 6.9l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 22l8.8-8.4a5.5 5.5 0 0 0 0-7.8Z" {...p} />}
      {name === "check" && <Path d="m5 12 4 4L19 6" {...p} />}
      {name === "arrow" && (<><Path d="M5 12h14" {...p} /><Path d="m14 7 5 5-5 5" {...p} /></>)}
      {name === "back" && (<><Path d="M19 12H5" {...p} /><Path d="m10 7-5 5 5 5" {...p} /></>)}
    </Svg>
  );
}
