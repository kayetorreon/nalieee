import Svg, { Path } from "react-native-svg";
import { colors } from "../theme";

// The cozy reading cat from the web prototype's welcome card.
export default function Mascot({ width = 150 }: { width?: number }) {
  const o = colors.outline;
  return (
    <Svg width={width} height={(width * 130) / 150} viewBox="0 0 150 130">
      <Path d="M17 113c19-14 96-15 119 0-19 15-102 15-119 0Z" fill="rgba(105,75,91,0.10)" />
      <Path d="m47 45-4-22 20 13c8-4 24-4 33 0l19-13-4 24c8 9 10 21 5 33-7 18-26 26-46 22-22-4-35-18-34-34 0-9 4-17 11-23Z" fill="#fff9ed" stroke={o} strokeWidth={2.2} strokeLinejoin="round" />
      <Path d="m51 31 4 12m51-12-3 12M59 61c4 5 10 5 14 0m14 0c4 5 10 5 14 0" fill="none" stroke={o} strokeWidth={2} strokeLinecap="round" />
      <Path d="m77 66 4 3 4-3" fill="#eba0af" stroke={o} strokeWidth={2} strokeLinecap="round" />
      <Path d="M77 83c-16-9-31-8-43-1l6 32c12-6 25-4 39 4Z" fill="#e99ab2" stroke={o} strokeWidth={2} />
      <Path d="M79 83c16-9 31-8 43-1l-6 32c-12-6-25-4-39 4Z" fill="#b6a8dc" stroke={o} strokeWidth={2} />
      <Path d="m78 86 1 29M45 91c8-3 17-2 25 2m27-2c7-3 12-3 18-1" fill="none" stroke={o} strokeWidth={2} strokeLinecap="round" />
      <Path d="m23 43 3 7 7 3-7 3-3 7-3-7-7-3 7-3Zm103 1 2 5 5 2-5 2-2 5-2-5-5-2 5-2Z" fill="#e69ab2" />
    </Svg>
  );
}
