import { useState } from "react";
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import AuthField from "../components/AuthField";
import Icon from "../components/Icon";
import PrimaryButton from "../components/PrimaryButton";
import { friendlyAuthError, useAuth } from "../context/AuthContext";
import { colors, fonts, shadowSmall } from "../theme";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type Errors = { name?: string; email?: string; password?: string; confirm?: string; form?: string };

export default function SignUpScreen({ onGoToSignIn }: { onGoToSignIn: () => void }) {
  const { signUp } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const next: Errors = {};
    if (!name.trim()) next.name = "Tell us what to call you.";
    if (!EMAIL_RE.test(email.trim())) next.email = "Enter a valid email address.";
    if (password.length < 6) next.password = "Use at least 6 characters."; // Firebase minimum
    if (confirm !== password) next.confirm = "Passwords don't match.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSignUp = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      await signUp(name, email, password);
    } catch (e) {
      setErrors({ form: friendlyAuthError(e) });
    } finally {
      setLoading(false);
    }
  };

  // Simple strength hint: 0-3
  const strength = Math.min(3, (password.length >= 6 ? 1 : 0) + (password.length >= 10 ? 1 : 0) + (/[A-Z]/.test(password) && /\d/.test(password) ? 1 : 0));
  const strengthLabel = ["", "A good start", "Getting stronger", "Lovely and strong"][strength];
  const strengthColors = [colors.line, colors.peach, colors.lavender, colors.sage];

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <TouchableOpacity onPress={onGoToSignIn} style={styles.back} accessibilityLabel="Back to sign in">
              <Icon name="back" size={20} />
            </TouchableOpacity>
            <View style={{ flex: 1 }}>
              <Text style={styles.eyebrow}>LET'S GET STARTED</Text>
              <Text style={styles.title}>Create your account</Text>
            </View>
          </View>

          <View style={styles.form}>
            {!!errors.form && <View style={styles.formError}><Text style={styles.formErrorText}>{errors.form}</Text></View>}

            <AuthField label="YOUR NAME" icon="user" placeholder="e.g. Analie" value={name} error={errors.name} onChangeText={setName} autoCapitalize="words" autoComplete="name" textContentType="name" />
            <AuthField
              label="EMAIL" icon="mail" placeholder="you@school.edu" value={email} error={errors.email}
              onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} autoComplete="email" textContentType="emailAddress"
            />
            <View style={{ gap: 8 }}>
              <AuthField
                label="PASSWORD" icon="lock" placeholder="At least 6 characters" value={password} error={errors.password}
                onChangeText={setPassword} secure autoCapitalize="none" autoComplete="new-password" textContentType="newPassword"
              />
              {password.length > 0 && (
                <View style={styles.strengthRow}>
                  <View style={styles.bars}>
                    {[1, 2, 3].map((i) => <View key={i} style={[styles.bar, { backgroundColor: strength >= i ? strengthColors[strength] : colors.line }]} />)}
                  </View>
                  <Text style={styles.strengthText}>{strengthLabel}</Text>
                </View>
              )}
            </View>
            <AuthField
              label="CONFIRM PASSWORD" icon="lock" placeholder="Type it once more" value={confirm} error={errors.confirm}
              onChangeText={setConfirm} secure autoCapitalize="none" autoComplete="new-password" textContentType="newPassword" onSubmitEditing={handleSignUp} returnKeyType="go"
            />

            <View style={styles.note}>
              <Icon name="heart" size={16} color={colors.sageInk} />
              <Text style={styles.noteText}>Your study data stays private and is only used to personalize your practice.</Text>
            </View>

            <PrimaryButton title="Create account" icon="sparkle" onPress={handleSignUp} loading={loading} />
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>Already have an account? </Text>
            <TouchableOpacity onPress={onGoToSignIn} hitSlop={8}><Text style={styles.link}>Sign in</Text></TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.cream },
  scroll: { padding: 20, paddingBottom: 32, gap: 22 },
  header: { flexDirection: "row", alignItems: "center", gap: 14, marginTop: 4 },
  back: {
    width: 44, height: 44, alignItems: "center", justifyContent: "center", borderRadius: 22,
    borderWidth: 1, borderColor: colors.line, backgroundColor: colors.white, ...shadowSmall,
  },
  eyebrow: { marginBottom: 4, color: colors.muted, fontFamily: fonts.bodyBold, fontSize: 10, letterSpacing: 1.4 },
  title: { color: colors.ink, fontFamily: fonts.heading, fontSize: 26, letterSpacing: -0.9 },
  form: { gap: 16 },
  formError: { padding: 12, borderRadius: 14, backgroundColor: colors.dangerSoft },
  formErrorText: { color: colors.danger, fontFamily: fonts.bodyMedium, fontSize: 12 },
  strengthRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  bars: { flexDirection: "row", gap: 4 },
  bar: { width: 34, height: 5, borderRadius: 3 },
  strengthText: { color: colors.muted, fontFamily: fonts.bodyMedium, fontSize: 11 },
  note: { flexDirection: "row", alignItems: "center", gap: 9, padding: 12, borderRadius: 15, backgroundColor: colors.sageSoft },
  noteText: { flex: 1, color: colors.sageInk, fontFamily: fonts.body, fontSize: 11, lineHeight: 16 },
  link: { color: colors.pink, fontFamily: fonts.bodyBold, fontSize: 12 },
  footer: { flexDirection: "row", justifyContent: "center", alignItems: "center" },
  footerText: { color: colors.muted, fontFamily: fonts.body, fontSize: 12 },
});
