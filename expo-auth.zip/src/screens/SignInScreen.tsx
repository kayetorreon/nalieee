import { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import AuthField from "../components/AuthField";
import Mascot from "../components/Mascot";
import PrimaryButton from "../components/PrimaryButton";
import { friendlyAuthError, useAuth } from "../context/AuthContext";
import { colors, fonts, shadow } from "../theme";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function SignInScreen({ onGoToSignUp }: { onGoToSignUp: () => void }) {
  const { signIn, resetPassword } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ email?: string; password?: string; form?: string }>({});
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const next: typeof errors = {};
    if (!EMAIL_RE.test(email.trim())) next.email = "Enter a valid email address.";
    if (!password) next.password = "Enter your password.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSignIn = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      await signIn(email, password);
      // AuthProvider's listener switches the app to the signed-in screens.
    } catch (e) {
      setErrors({ form: friendlyAuthError(e) });
    } finally {
      setLoading(false);
    }
  };

  const handleForgot = async () => {
    if (!EMAIL_RE.test(email.trim())) {
      setErrors({ email: "Enter your email above, then tap Forgot password." });
      return;
    }
    try {
      await resetPassword(email);
      Alert.alert("Check your inbox", "If an account exists for that email, a reset link is on its way.");
    } catch (e) {
      Alert.alert("Couldn't send email", friendlyAuthError(e));
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.hero}>
            <View style={styles.sticker}><Text style={styles.stickerText}>Your little study world</Text></View>
            <Text style={styles.heroTitle}>Welcome back!</Text>
            <Text style={styles.heroSub}>Sign in to pick up where you left off.</Text>
            <View style={styles.mascot}><Mascot width={128} /></View>
          </View>

          <View style={styles.form}>
            {!!errors.form && <View style={styles.formError}><Text style={styles.formErrorText}>{errors.form}</Text></View>}

            <AuthField
              label="EMAIL" icon="mail" placeholder="you@school.edu" value={email} error={errors.email}
              onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} autoComplete="email" textContentType="emailAddress"
            />
            <AuthField
              label="PASSWORD" icon="lock" placeholder="Your password" value={password} error={errors.password}
              onChangeText={setPassword} secure autoCapitalize="none" autoComplete="password" textContentType="password" onSubmitEditing={handleSignIn} returnKeyType="go"
            />

            <TouchableOpacity onPress={handleForgot} style={styles.forgot} hitSlop={8}>
              <Text style={styles.link}>Forgot password?</Text>
            </TouchableOpacity>

            <PrimaryButton title="Sign in" onPress={handleSignIn} loading={loading} />
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>New here? </Text>
            <TouchableOpacity onPress={onGoToSignUp} hitSlop={8}><Text style={styles.link}>Create an account</Text></TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.cream },
  scroll: { padding: 20, paddingBottom: 32, gap: 22 },
  hero: {
    minHeight: 190, padding: 22, borderRadius: 28, borderWidth: 1, borderColor: "rgba(233,143,172,0.26)",
    backgroundColor: "#fbeff2", overflow: "hidden", ...shadow,
  },
  sticker: {
    alignSelf: "flex-start", paddingVertical: 6, paddingHorizontal: 10, borderRadius: 999,
    borderWidth: 1, borderColor: "rgba(233,143,172,0.28)", backgroundColor: "rgba(255,255,255,0.7)", transform: [{ rotate: "-1deg" }],
  },
  stickerText: { color: "#a95f79", fontFamily: fonts.hand, fontSize: 15 },
  heroTitle: { marginTop: 14, color: colors.ink, fontFamily: fonts.heading, fontSize: 28, letterSpacing: -1 },
  heroSub: { marginTop: 6, width: "58%", color: "#806c78", fontFamily: fonts.body, fontSize: 12, lineHeight: 17 },
  mascot: { position: "absolute", right: -6, bottom: -4 },
  form: { gap: 16 },
  formError: { padding: 12, borderRadius: 14, backgroundColor: colors.dangerSoft },
  formErrorText: { color: colors.danger, fontFamily: fonts.bodyMedium, fontSize: 12 },
  forgot: { alignSelf: "flex-end", marginTop: -4 },
  link: { color: colors.pink, fontFamily: fonts.bodyBold, fontSize: 12 },
  footer: { flexDirection: "row", justifyContent: "center", alignItems: "center" },
  footerText: { color: colors.muted, fontFamily: fonts.body, fontSize: 12 },
});
