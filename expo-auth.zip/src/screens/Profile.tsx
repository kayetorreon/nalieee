import React from "react";
import { StyleSheet, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Card, Header, Icon, IconButton, IconName, SectionHeading, T, Tap } from "../components";
import { c, f, shadowSmall, Tone, tones } from "../theme";

export default function Profile() {
  const items: { icon: IconName; title: string; note?: string; tone: Tone }[] = [
    { icon: "user", title: "My profile", note: "Personal details", tone: "pink" },
    { icon: "book", title: "My subjects", note: "6 active subjects", tone: "lavender" },
    { icon: "target", title: "My goals", note: "3 in progress", tone: "green" },
    { icon: "bell", title: "Notifications", note: "Study reminders on", tone: "peach" },
    { icon: "moon", title: "Appearance", note: "Blossom light", tone: "blue" },
    { icon: "settings", title: "Settings", tone: "neutral" },
  ];
  const ink = "#6d525b";
  return (
    <View>
      <Header eyebrow="YOUR STUDY SPACE" title="Profile" action={<IconButton icon="edit" />} />

      <LinearGradient colors={["#fff0f4", "#f1ecfa"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.hero}>
        <View style={s.avatar}>
          <View style={s.face}>
            <View style={{ height: 8, backgroundColor: ink, borderTopLeftRadius: 23, borderTopRightRadius: 23 }} />
            <View style={[s.eye, { left: 14 }]} />
            <View style={[s.eye, { right: 14 }]} />
            <View style={s.mouth} />
          </View>
          <T style={s.bow}>⌁</T>
        </View>
        <View style={{ flex: 1 }}>
          <T style={{ fontFamily: f.head, fontSize: 24 }}>Analie</T>
          <T style={{ color: c.muted, fontSize: 11 }}>BS Information Technology</T>
          <View style={s.year}><T style={{ color: "#9c6782", fontFamily: f.bodyBold, fontSize: 9 }}>3rd Year</T></View>
        </View>
        <View style={{ position: "absolute", right: 14, top: 14 }}><Icon name="sparkle" color="#b6a5da" /></View>
      </LinearGradient>

      <Card style={s.strip}>
        {[["7", "day streak"], ["24", "sessions"], ["84%", "accuracy"]].map(([v, l], i) => (
          <View key={l} style={[{ flex: 1, alignItems: "center" }, i < 2 && { borderRightWidth: 1, borderStyle: "dashed", borderColor: c.line }]}>
            <T style={{ fontFamily: f.head, fontSize: 18 }}>{v}</T>
            <T style={{ color: c.muted, fontSize: 9 }}>{l}</T>
          </View>
        ))}
      </Card>

      <SectionHeading title="Your space" />
      <Card style={{ overflow: "hidden" }}>
        {items.map((item, i) => (
          <Tap key={item.title} style={[s.row, i < items.length - 1 && { borderBottomWidth: 1, borderStyle: "dashed", borderColor: c.line }]}>
            <View style={[s.menuIcon, { backgroundColor: tones[item.tone].bg }]}><Icon name={item.icon} color={tones[item.tone].fg} /></View>
            <View style={{ flex: 1, gap: 2 }}>
              <T style={{ fontFamily: f.bodyBold, fontSize: 12 }}>{item.title}</T>
              {item.note ? <T style={{ color: c.muted, fontSize: 10 }}>{item.note}</T> : null}
            </View>
            <Icon name="chevron" size={17} color="#b7aab1" />
          </Tap>
        ))}
      </Card>

      <View style={s.note}>
        <Icon name="heart" color="#b86980" />
        <View style={{ flex: 1, gap: 3 }}>
          <T style={{ fontFamily: f.head, fontSize: 12, color: "#b86980" }}>A little reminder</T>
          <T style={{ color: "#9e7b87", fontSize: 10, lineHeight: 15 }}>Progress is progress, no matter how small. You're doing wonderfully.</T>
        </View>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  hero: { flexDirection: "row", alignItems: "center", gap: 17, padding: 19, borderRadius: 26, borderWidth: 1, borderColor: "#eaddeb" },
  avatar: { width: 76, height: 76, borderRadius: 24, borderWidth: 5, borderColor: "rgba(255,255,255,0.8)", backgroundColor: "#f5cfb9", alignItems: "center", justifyContent: "center", ...shadowSmall },
  face: { width: 49, height: 46, borderTopLeftRadius: 23, borderTopRightRadius: 23, borderBottomLeftRadius: 19, borderBottomRightRadius: 19, backgroundColor: "#fff2e2", overflow: "hidden" },
  eye: { position: "absolute", top: 25, width: 4, height: 5, borderRadius: 3, backgroundColor: "#6d525b" },
  mouth: { position: "absolute", left: 22, top: 31, width: 7, height: 4, borderBottomWidth: 1, borderColor: "#bd7885", borderRadius: 4 },
  bow: { position: "absolute", right: -8, top: -14, color: "#bc6984", fontFamily: f.hand, fontSize: 34, transform: [{ rotate: "-25deg" }] },
  year: { alignSelf: "flex-start", marginTop: 7, paddingVertical: 4, paddingHorizontal: 8, borderRadius: 99, backgroundColor: "rgba(255,255,255,0.7)" },
  strip: { flexDirection: "row", marginTop: 12, padding: 15, borderRadius: 20 },
  row: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12, paddingHorizontal: 14 },
  menuIcon: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  note: { flexDirection: "row", gap: 12, marginTop: 18, padding: 15, borderRadius: 19, backgroundColor: c.pinkPale },
});
