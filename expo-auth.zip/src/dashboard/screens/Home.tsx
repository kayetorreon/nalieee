import React, { useState } from "react";
import { StyleSheet, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Card, Header, Icon, IconButton, Mascot, Progress, SectionHeading, Sticker, T, Tap } from "../components";
import { c, f, shadow, shadowSmall, tones } from "../theme";
import type { Tab } from "../types";

const initialTasks = [
  { title: "Finish database assignment", meta: "Today · 4:00 PM", tone: "pink", done: false },
  { title: "Review programming notes", meta: "Today · 6:30 PM", tone: "lavender", done: false },
  { title: "Read Chapter 4", meta: "Tomorrow · 30 min", tone: "green", done: false },
] as const;

export default function Home({ go }: { go: (tab: Tab) => void }) {
  const [tasks, setTasks] = useState<{ title: string; meta: string; tone: "pink" | "lavender" | "green"; done: boolean }[]>([...initialTasks]);
  const toggle = (i: number) => setTasks(tasks.map((t, idx) => (idx === i ? { ...t, done: !t.done } : t)));
  const stats = [["18", "questions"], ["42", "minutes"], ["84%", "accuracy"], ["7", "day streak"]];

  return (
    <View>
      <Header eyebrow="TUESDAY, MAY 21" title="Good morning, Analie!" action={<IconButton icon="bell" />} />

      <LinearGradient colors={["#ffe9ef", "#fbeff2", "#eee7f7"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.welcome}>
        <View style={s.dashed} />
        <View style={{ width: "61%", zIndex: 2 }}>
          <Sticker>Your little study world</Sticker>
          <T style={s.heroTitle}>{"Ready for a little\nstudy adventure?"}</T>
          <T style={{ marginTop: 8, color: "#806c78" }}>A cozy plan is waiting for you.</T>
        </View>
        <Mascot style={s.mascot} />
      </LinearGradient>

      <Card style={{ marginTop: 14, padding: 18, backgroundColor: c.paper }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 7 }}>
          <Icon name="sparkle" size={16} color="#af6880" />
          <T style={{ color: "#af6880", fontFamily: f.bodyBold, fontSize: 10, letterSpacing: 1.2 }}>TODAY'S STUDY</T>
        </View>
        <View style={{ flexDirection: "row", marginTop: 15 }}>
          {stats.map(([v, l], i) => (
            <View key={l} style={[s.stat, i < 3 && s.dashedRight]}>
              <T style={{ fontFamily: f.head, fontSize: 18 }}>{v}</T>
              <T style={{ marginTop: 2, color: c.muted, fontSize: 10 }}>{l}</T>
            </View>
          ))}
        </View>
      </Card>

      <SectionHeading title="Continue learning" icon="book" tone="lavender" action="View all" onAction={() => go("practice")} />
      <Card style={s.rowCard}>
        <View style={s.bookStack}>
          <View style={[s.bookTab, { backgroundColor: c.pinkSoft, transform: [{ rotate: "7deg" }, { translateX: 4 }, { translateY: -2 }] }]} />
          <View style={[s.bookTab, { backgroundColor: c.sageSoft, transform: [{ rotate: "-9deg" }, { translateX: -4 }, { translateY: 1 }] }]} />
          <View style={s.bookCover}>
            <Icon name="book" size={29} color="#7768a2" />
          </View>
        </View>
        <View style={{ flex: 1 }}>
          <T style={s.cardLabel}>PROGRAMMING FUNDAMENTALS</T>
          <T style={s.cardTitle}>Data Structures</T>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginTop: 11 }}>
            <Progress value={60} />
            <T style={{ color: c.muted, fontSize: 10 }}>12/20</T>
          </View>
        </View>
        <Tap style={s.roundArrow} onPress={() => go("practice")}>
          <Icon name="arrow" size={19} color={c.white} />
        </Tap>
      </Card>

      <LinearGradient colors={["#f5f0fc", "#fff6fa"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0.3 }} style={s.magic}>
        <View style={s.magicOrb}>
          <Icon name="sparkle" size={24} color="#8b78bd" />
        </View>
        <View style={{ flex: 1 }}>
          <T style={s.cardTitle}>Learning Magic</T>
          <T style={{ color: c.muted, marginTop: 2 }}>Your practice is adapting to your pace.</T>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 7, marginTop: 9 }}>
            <T style={s.level}>Easy</T>
            <T style={[s.level, s.levelActive]}>Medium</T>
            <T style={s.level}>Hard</T>
          </View>
        </View>
        <T style={{ position: "absolute", right: 15, top: 9, color: "#c9bce8", fontSize: 14 }}>✦</T>
      </LinearGradient>

      <SectionHeading title="Today's tasks" icon="check" tone="peach" action="View all" onAction={() => go("tasks")} />
      <Card style={{ overflow: "hidden" }}>
        {tasks.map((task, i) => {
          const t = tones[task.tone];
          return (
            <Tap key={task.title} onPress={() => toggle(i)} style={[s.taskRow, i < tasks.length - 1 && s.dashedBottom]}>
              <View style={[s.taskCheck, { borderColor: t.fg, backgroundColor: t.bg }]}>{task.done && <Icon name="check" size={14} color={t.fg} />}</View>
              <View style={{ flex: 1, gap: 2 }}>
                <T style={[{ fontFamily: f.bodyBold }, task.done && { color: c.muted, textDecorationLine: "line-through" }]}>{task.title}</T>
                <T style={{ color: c.muted, fontSize: 10 }}>{task.meta}</T>
              </View>
              <Icon name="chevron" size={17} color="#b7aab1" />
            </Tap>
          );
        })}
      </Card>

      <SectionHeading title="Current goals" icon="target" tone="green" />
      <Card style={s.rowCard}>
        <View style={[s.goalIcon]}>
          <Icon name="sprout" color="#648e6e" />
        </View>
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 9 }}>
            <T style={{ fontFamily: f.bodyBold }}>Learn JavaScript</T>
            <T style={{ color: "#648e6e", fontFamily: f.bodyBold }}>80%</T>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Progress value={80} tone="green" />
          </View>
          <T style={{ color: c.muted, fontSize: 10, marginTop: 6 }}>8 of 10 milestones</T>
        </View>
      </Card>
    </View>
  );
}

const s = StyleSheet.create({
  welcome: { minHeight: 184, padding: 22, paddingRight: 16, paddingBottom: 20, borderRadius: 28, overflow: "hidden", borderWidth: 1, borderColor: "rgba(233,143,172,0.26)", flexDirection: "row", ...shadow },
  dashed: { position: "absolute", width: 130, height: 130, right: -20, top: -40, borderRadius: 65, borderWidth: 2, borderStyle: "dashed", borderColor: "rgba(255,255,255,0.7)" },
  heroTitle: { marginTop: 14, fontFamily: f.head, fontSize: 24, lineHeight: 27, letterSpacing: -1 },
  mascot: { position: "absolute", right: -1, bottom: -1, width: "47%", aspectRatio: 150 / 130 },
  stat: { flex: 1, alignItems: "center" },
  dashedRight: { borderRightWidth: 1, borderStyle: "dashed", borderColor: c.line },
  dashedBottom: { borderBottomWidth: 1, borderStyle: "dashed", borderColor: c.line },
  rowCard: { flexDirection: "row", alignItems: "center", gap: 14, padding: 16 },
  bookStack: { width: 62, height: 70, alignItems: "center", justifyContent: "center" },
  bookTab: { position: "absolute", width: 49, height: 56, borderTopLeftRadius: 8, borderBottomLeftRadius: 8, borderTopRightRadius: 13, borderBottomRightRadius: 13 },
  bookCover: { width: 52, height: 58, alignItems: "center", justifyContent: "center", backgroundColor: c.lavenderSoft, borderTopLeftRadius: 8, borderBottomLeftRadius: 8, borderTopRightRadius: 13, borderBottomRightRadius: 13, transform: [{ rotate: "-3deg" }], borderLeftWidth: 5, borderLeftColor: "rgba(255,255,255,0.6)" },
  cardLabel: { color: c.muted, fontSize: 10, fontFamily: f.bodyBold, letterSpacing: 1.4, marginBottom: 4 },
  cardTitle: { fontFamily: f.head, fontSize: 16, lineHeight: 19 },
  roundArrow: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", backgroundColor: c.ink },
  magic: { flexDirection: "row", alignItems: "center", gap: 14, marginTop: 13, padding: 17, borderRadius: 22, borderWidth: 1, borderColor: "#e3daf4", overflow: "hidden" },
  magicOrb: { width: 47, height: 47, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: c.white, ...shadowSmall },
  level: { color: "#a89aa4", fontSize: 10, fontFamily: f.bodyBold },
  levelActive: { backgroundColor: c.lavender, color: c.white, paddingVertical: 5, paddingHorizontal: 9, borderRadius: 99, overflow: "hidden" },
  taskRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 14, paddingHorizontal: 15 },
  taskCheck: { width: 23, height: 23, borderRadius: 8, borderWidth: 2, alignItems: "center", justifyContent: "center" },
  goalIcon: { width: 48, height: 48, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: c.sageSoft },
});
