import React, { useState } from "react";
import { StyleSheet, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Header, Icon, T, Tap } from "../components";
import { c, f, shadowSmall } from "../theme";

type TaskColor = "pink" | "lavender" | "green";
const palette: Record<TaskColor, { bg: string; fg: string }> = {
  pink: { bg: "#fff0f4", fg: "#ad617a" },
  lavender: { bg: "#f1edfa", fg: "#7768a2" },
  green: { bg: "#edf5eb", fg: "#648e6e" },
};

export default function Tasks() {
  const [filter, setFilter] = useState("Today");
  const [tasks, setTasks] = useState<{ title: string; subject: string; due: string; time: string; priority: string; color: TaskColor; done: boolean }[]>([
    { title: "Finish Database Assignment", subject: "Database Systems", due: "Today, 4:00 PM", time: "1 hour", priority: "High", color: "pink", done: false },
    { title: "Review Programming Notes", subject: "Programming", due: "Today, 6:30 PM", time: "30 min", priority: "Medium", color: "lavender", done: false },
    { title: "Read Chapter 4", subject: "Networking", due: "Tomorrow", time: "45 min", priority: "Low", color: "green", done: false },
  ]);
  const toggle = (i: number) => setTasks(tasks.map((t, idx) => (idx === i ? { ...t, done: !t.done } : t)));

  return (
    <View>
      <Header
        eyebrow="COZY PLANNER"
        title="Today's little plan"
        action={
          <Tap style={s.add}>
            <Icon name="plus" size={18} color={c.white} />
            <T style={{ color: c.white, fontFamily: f.bodyBold, fontSize: 12 }}>Add</T>
          </Tap>
        }
      />
      <LinearGradient colors={["#f6f1fb", "#fff6f7"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0.3 }} style={s.summary}>
        <T style={s.flower}>✿</T>
        <View style={s.dateBox}>
          <T style={{ color: c.muted, fontSize: 10 }}>Tuesday</T>
          <T style={{ fontFamily: f.head, fontSize: 26, lineHeight: 30 }}>21</T>
          <T style={{ color: c.muted, fontSize: 10 }}>May</T>
        </View>
        <View style={{ flex: 1, gap: 4 }}>
          <T style={{ fontFamily: f.head, fontSize: 15 }}>3 things to do</T>
          <T style={{ color: c.muted, fontSize: 11, lineHeight: 15 }}>You've got plenty of time. One step at a time.</T>
        </View>
      </LinearGradient>

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 14, marginBottom: 17 }}>
        {["All", "Today", "Upcoming", "Important", "Done"].map((item) => (
          <Tap key={item} onPress={() => setFilter(item)} style={[s.chip, filter === item && s.chipOn]}>
            <T style={{ fontFamily: f.bodyBold, fontSize: 12, color: filter === item ? c.white : c.muted }}>{item}</T>
          </Tap>
        ))}
      </View>

      <View style={{ gap: 11 }}>
        {tasks.map((task, i) => {
          const p = palette[task.color];
          return (
            <View key={task.title} style={[s.sticky, { backgroundColor: p.bg }, task.done && { opacity: 0.58, transform: [{ scale: 0.98 }] }]}>
              <View style={[s.accent, { backgroundColor: p.fg }]} />
              <Tap style={[s.largeCheck, { borderColor: p.fg }]} onPress={() => toggle(i)}>
                {task.done && <Icon name="check" size={18} color={p.fg} />}
              </Tap>
              <View style={{ flex: 1 }}>
                <T style={{ color: p.fg, fontFamily: f.bodyBold, fontSize: 10, letterSpacing: 0.9 }}>{task.subject.toUpperCase()}</T>
                <T style={[{ marginTop: 4, fontFamily: f.head, fontSize: 15 }, task.done && { textDecorationLine: "line-through" }]}>{task.title}</T>
                <View style={{ flexDirection: "row", gap: 12, marginTop: 8 }}>
                  <View style={s.detail}><Icon name="calendar" size={15} color={c.muted} /><T style={s.detailText}>{task.due}</T></View>
                  <View style={s.detail}><Icon name="clock" size={15} color={c.muted} /><T style={s.detailText}>{task.time}</T></View>
                </View>
                <View style={s.priority}>
                  <T style={{ color: p.fg, fontFamily: f.bodyBold, fontSize: 9 }}>{task.priority.toUpperCase()} PRIORITY</T>
                </View>
              </View>
              <Tap><T style={{ color: c.muted, fontFamily: f.bodyBold, letterSpacing: 2 }}>•••</T></Tap>
            </View>
          );
        })}
      </View>

      <View style={s.callout}>
        <View style={s.calloutIcon}><Icon name="calendar" color="#b8627c" /></View>
        <View style={{ flex: 1 }}>
          <T style={{ fontFamily: f.head, fontSize: 12 }}>Let magic plan your week</T>
          <T style={{ color: c.muted, fontSize: 10, marginTop: 2 }}>We'll arrange tasks around your best study times.</T>
        </View>
        <Tap style={s.pale}><Icon name="arrow" size={18} color="#af6880" /></Tap>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  add: { flexDirection: "row", alignItems: "center", gap: 5, paddingVertical: 10, paddingHorizontal: 14, borderRadius: 99, backgroundColor: c.pink },
  summary: { flexDirection: "row", alignItems: "center", gap: 15, padding: 17, borderRadius: 24, borderWidth: 1, borderColor: "#e8dff1", overflow: "hidden" },
  flower: { position: "absolute", right: -8, top: -12, color: "#e7c1d0", fontSize: 52, transform: [{ rotate: "15deg" }] },
  dateBox: { width: 58, height: 70, alignItems: "center", justifyContent: "center", borderRadius: 16, backgroundColor: c.white, ...shadowSmall },
  chip: { paddingVertical: 8, paddingHorizontal: 16, borderRadius: 99, borderWidth: 1, borderColor: c.line, backgroundColor: c.white },
  chipOn: { borderColor: c.pink, backgroundColor: c.pink },
  sticky: { flexDirection: "row", gap: 12, paddingVertical: 17, paddingHorizontal: 13, borderTopLeftRadius: 6, borderBottomLeftRadius: 6, borderTopRightRadius: 21, borderBottomRightRadius: 21, overflow: "hidden", ...shadowSmall },
  accent: { position: "absolute", left: 0, top: 0, bottom: 0, width: 5, opacity: 0.55 },
  largeCheck: { width: 25, height: 25, marginTop: 2, borderRadius: 8, borderWidth: 2, alignItems: "center", justifyContent: "center" },
  detail: { flexDirection: "row", alignItems: "center", gap: 4 },
  detailText: { color: c.muted, fontSize: 10 },
  priority: { alignSelf: "flex-start", marginTop: 9, paddingVertical: 4, paddingHorizontal: 7, borderRadius: 99, backgroundColor: "rgba(255,255,255,0.62)" },
  callout: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 22, padding: 15, borderWidth: 1, borderStyle: "dashed", borderColor: "#dcb7c6", borderRadius: 20, backgroundColor: c.white },
  calloutIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: c.pinkSoft },
  pale: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", backgroundColor: c.pinkPale },
});
