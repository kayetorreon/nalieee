import React, { useState } from "react";
import { StyleSheet, TextInput, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import * as DocumentPicker from "expo-document-picker";
import { Header, Icon, IconButton, IconName, Progress, SectionHeading, Sticker, T, Tap, Card } from "../components";
import { c, f, shadow, shadowSmall, Tone, tones } from "../theme";

const practiceCards: { title: string; subject: string; level: string; questions: number; time: number; tone: Tone }[] = [
  { title: "Binary Trees", subject: "Data Structures", level: "Easy", questions: 20, time: 10, tone: "green" },
  { title: "Object-Oriented Programming", subject: "Programming", level: "Medium", questions: 15, time: 12, tone: "pink" },
  { title: "Database Normalization", subject: "Database Systems", level: "Hard", questions: 12, time: 15, tone: "lavender" },
];

const lbl = { color: c.muted, fontSize: 10, fontFamily: f.bodyBold, letterSpacing: 1.4 } as const;

function Field({ label, optional, ...input }: { label: string; optional?: boolean } & React.ComponentProps<typeof TextInput>) {
  const [focus, setFocus] = useState(false);
  return (
    <View style={{ gap: 7 }}>
      <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
        <T style={{ ...lbl, fontSize: 10 }}>{label}</T>
        {optional ? <T style={{ color: "#b8abb2", fontSize: 10 }}>Optional</T> : null}
      </View>
      <TextInput
        {...input}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        placeholderTextColor="#b9adb3"
        style={[s.input, input.multiline && s.textarea, focus && { borderColor: c.pink }, input.style]}
      />
    </View>
  );
}

export default function Practice() {
  const [query, setQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState("All");
  const [inQuiz, setInQuiz] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);
  const [flashMode, setFlashMode] = useState<"choose" | "manual" | "ai" | null>(null);
  const [deckTitle, setDeckTitle] = useState("");
  const [front, setFront] = useState("");
  const [back, setBack] = useState("");
  const [notes, setNotes] = useState("");
  const [uploaded, setUploaded] = useState<string | null>(null);
  const [savedDeck, setSavedDeck] = useState<string | null>(null);
  const [count, setCount] = useState("20");

  const filtered = practiceCards.filter(
    (card) => (activeFilter === "All" || card.level === activeFilter) && card.title.toLowerCase().includes(query.toLowerCase())
  );

  const pickFile = async () => {
    const res = await DocumentPicker.getDocumentAsync({
      type: ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain", "image/*"],
    });
    if (!res.canceled && res.assets[0]) setUploaded(res.assets[0].name);
  };

  /* ---------- Flashcard studio ---------- */
  if (flashMode) {
    const canCreate = flashMode === "manual" ? front.trim() && back.trim() : notes.trim() || uploaded;
    const finishDeck = () => {
      if (!canCreate) return;
      setSavedDeck(deckTitle.trim() || (flashMode === "ai" ? "My AI Study Set" : "My Flashcards"));
      setDeckTitle(""); setFront(""); setBack(""); setNotes(""); setUploaded(null);
      setFlashMode(null);
    };
    return (
      <View>
        <Header
          eyebrow="FLASHCARD STUDIO"
          title={flashMode === "choose" ? "Make it yours" : flashMode === "manual" ? "Create flashcards" : "Create with AI"}
          action={<Tap style={s.close} onPress={() => setFlashMode(null)}><T style={{ fontSize: 23, color: c.muted, lineHeight: 26 }}>×</T></Tap>}
        />
        {flashMode === "choose" ? (
          <>
            <LinearGradient colors={["#fff0f4", "#f2edfa"]} style={s.flashIntro}>
              <View style={s.stackBig}>
                <View style={[s.stackCard, { backgroundColor: c.lavenderSoft, transform: [{ rotate: "-9deg" }, { translateX: -4 }] }]} />
                <View style={[s.stackCard, { backgroundColor: c.pinkSoft, transform: [{ rotate: "8deg" }, { translateX: 4 }] }]} />
                <View style={[s.stackCard, s.stackTop]}><Icon name="sparkle" size={27} color="#8976b8" /></View>
              </View>
              <T style={{ fontFamily: f.head, fontSize: 20, marginBottom: 5, textAlign: "center" }}>How would you like to make your set?</T>
              <T style={{ color: c.muted, textAlign: "center", lineHeight: 18, maxWidth: 290 }}>Start from scratch, or let Learning Magic turn your notes into ready-to-study cards.</T>
            </LinearGradient>
            <View style={{ gap: 11, marginTop: 17 }}>
              <Option icon="edit" tone="pink" title="Create manually" note="Write your own questions and answers" onPress={() => setFlashMode("manual")} />
              <Option icon="sparkle" tone="lavender" title="Create with AI" note="Paste or upload notes to make a set" onPress={() => setFlashMode("ai")} />
            </View>
            <View style={s.magicNote}>
              <Icon name="heart" color="#648e6e" />
              <T style={{ flex: 1, color: "#648e6e", fontSize: 10, lineHeight: 15 }}>Your notes stay private and are only used to create your study set.</T>
            </View>
          </>
        ) : (
          <>
            <Field label="SET TITLE" optional value={deckTitle} onChangeText={setDeckTitle} placeholder="e.g. Database Midterm" />
            {flashMode === "manual" ? (
              <>
                <View style={s.counter}>
                  <T style={{ fontFamily: f.head, fontSize: 13 }}>Card 1</T>
                  <T style={{ color: c.muted, fontSize: 10 }}>1 card in this set</T>
                </View>
                <Card style={{ padding: 17 }}>
                  <Field label="FRONT" multiline value={front} onChangeText={setFront} placeholder="Type a term or question..." />
                  <View style={s.divider}>
                    <View style={s.divLine} />
                    <View style={s.divIcon}><Icon name="arrow" size={15} color="#b8627c" /></View>
                    <View style={s.divLine} />
                  </View>
                  <Field label="BACK" multiline value={back} onChangeText={setBack} placeholder="Type the answer or definition..." />
                </Card>
                <Tap style={s.addAnother}>
                  <Icon name="plus" size={17} color="#aa6178" />
                  <T style={{ color: "#aa6178", fontFamily: f.bodyBold, fontSize: 11 }}>Add another card</T>
                </Tap>
              </>
            ) : (
              <>
                <View style={s.aiHelper}>
                  <View style={s.aiIcon}><Icon name="sparkle" color="#7768a2" /></View>
                  <View style={{ flex: 1, gap: 3 }}>
                    <T style={{ fontFamily: f.head, fontSize: 12, color: "#7768a2" }}>Learning Magic can help</T>
                    <T style={{ color: "#8d80ac", fontSize: 10, lineHeight: 14 }}>We'll find key ideas and turn them into clear flashcards. You can edit every card afterward.</T>
                  </View>
                </View>
                <Field
                  label="PASTE YOUR NOTES"
                  multiline
                  value={notes}
                  onChangeText={setNotes}
                  placeholder={"Paste lecture notes, a study guide, or any text here...\n\nThe more detail you share, the better your cards will be."}
                  style={{ minHeight: 180 }}
                />
                <T style={{ alignSelf: "flex-end", color: "#b6a9af", fontSize: 9, marginTop: 4 }}>{notes.length} characters</T>
                <View style={s.or}>
                  <View style={s.divLine} /><T style={{ color: "#aa9ca3", fontSize: 10 }}>or</T><View style={s.divLine} />
                </View>
                <Tap style={s.upload} onPress={pickFile}>
                  <View style={s.uploadIcon}><Icon name="plus" color="#7768a2" /></View>
                  <T style={{ fontFamily: f.head, fontSize: 12 }}>Upload your notes</T>
                  <T style={{ color: c.muted, fontSize: 9, marginTop: 3 }}>PDF, DOC, TXT, or an image · up to 10 MB</T>
                  {uploaded ? (
                    <View style={s.uploadedPill}>
                      <Icon name="check" size={14} color="#648e6e" />
                      <T style={{ color: "#648e6e", fontSize: 9, fontFamily: f.bodyBold }}>{uploaded}</T>
                    </View>
                  ) : null}
                </Tap>
                <View style={s.genOptions}>
                  <T style={{ color: c.muted, fontFamily: f.bodyBold, fontSize: 11 }}>Cards to create</T>
                  <View style={{ flexDirection: "row", gap: 5 }}>
                    {["10", "20", "30"].map((n) => (
                      <Tap key={n} onPress={() => setCount(n)} style={[s.count, count === n && s.countOn]}>
                        <T style={{ color: count === n ? "#aa6178" : c.muted, fontSize: 12 }}>{n}</T>
                      </Tap>
                    ))}
                  </View>
                </View>
              </>
            )}
            <Tap style={[s.primary, { marginTop: 20 }, !canCreate && { opacity: 0.45 }]} onPress={finishDeck}>
              <Icon name={flashMode === "ai" ? "sparkle" : "check"} size={18} color={c.white} />
              <T style={s.primaryText}>{flashMode === "ai" ? "Generate flashcards" : "Save flashcard set"}</T>
            </Tap>
          </>
        )}
      </View>
    );
  }

  /* ---------- Quiz ---------- */
  if (inQuiz) {
    const correct = selected === 1;
    return (
      <View>
        <Header eyebrow="DATA STRUCTURES" title="Question 8 of 20" action={<View style={s.badge}><T style={{ color: "#ad617a", fontFamily: f.bodyBold, fontSize: 11 }}>Medium</T></View>} />
        <View style={{ marginBottom: 18, flexDirection: "row" }}><Progress value={40} /></View>
        <View style={s.strip}>
          <Icon name="sparkle" size={18} color="#7768a2" />
          <View>
            <T style={{ fontFamily: f.head, fontSize: 12, color: "#7768a2" }}>Learning Magic</T>
            <T style={{ color: "#8f82ae", fontSize: 10 }}>Adjusting your practice to your pace...</T>
          </View>
        </View>
        <Card style={s.questionCard}>
          <T style={{ ...lbl, textAlign: "center" }}>CHOOSE ONE ANSWER</T>
          <T style={s.question}>Which data structure uses FIFO?</T>
        </Card>
        <View style={{ gap: 9 }}>
          {["Stack", "Queue", "Tree", "Graph"].map((answer, i) => {
            const on = selected === i;
            const ok = on && i === 1;
            const bad = on && i !== 1;
            return (
              <Tap key={answer} onPress={() => setSelected(i)} style={[s.answer, ok && { borderColor: "#93b99a", backgroundColor: c.sageSoft }, bad && { borderColor: "#e6a3b6", backgroundColor: c.pinkPale }]}>
                <View style={s.letter}><T style={{ color: c.muted, fontFamily: f.bodyBold, fontSize: 12 }}>{String.fromCharCode(65 + i)}</T></View>
                <T style={{ flex: 1, fontFamily: f.bodyBold, color: ok ? "#557d5e" : bad ? "#a95f77" : c.ink }}>{answer}</T>
                {on && <Icon name={ok ? "check" : "heart"} size={19} color={ok ? "#557d5e" : "#a95f77"} />}
              </Tap>
            );
          })}
        </View>
        {selected !== null && (
          <View style={[s.feedback, { backgroundColor: correct ? c.sageSoft : c.pinkPale }]}>
            <View style={s.feedbackIcon}><Icon name={correct ? "sparkle" : "heart"} color={correct ? "#557d5e" : "#9c5c72"} /></View>
            <View style={{ flex: 1 }}>
              <T style={{ fontFamily: f.head, fontSize: 16, color: correct ? "#557d5e" : "#9c5c72" }}>{correct ? "Correct!" : "Almost!"}</T>
              <T style={{ fontSize: 11, color: correct ? "#557d5e" : "#9c5c72" }}>{correct ? "You're getting the hang of it!" : "A queue processes the first item added first. Let's keep going."}</T>
            </View>
          </View>
        )}
        <Tap style={[s.primary, selected === null && { opacity: 0.45 }]} onPress={() => { if (selected !== null) { setInQuiz(false); setSelected(null); } }}>
          <T style={s.primaryText}>{selected === null ? "Choose an answer" : "Continue"}</T>
          <Icon name="arrow" size={18} color={c.white} />
        </Tap>
      </View>
    );
  }

  /* ---------- Practice list ---------- */
  return (
    <View>
      <Header eyebrow="YOUR PRACTICE SPACE" title="What shall we learn?" action={<IconButton icon="bell" />} />
      <View style={s.search}>
        <Icon name="search" color={c.muted} />
        <TextInput value={query} onChangeText={setQuery} placeholder="Search a topic..." placeholderTextColor="#b8abb2" style={{ flex: 1, fontFamily: f.body, fontSize: 14, color: c.ink }} />
      </View>
      <View style={{ flexDirection: "row", gap: 8, marginTop: 14, marginBottom: 20 }}>
        {["All", "Easy", "Medium", "Hard"].map((filter) => (
          <Tap key={filter} onPress={() => setActiveFilter(filter)} style={[s.chip, activeFilter === filter && s.chipOn]}>
            <T style={{ fontFamily: f.bodyBold, fontSize: 12, color: activeFilter === filter ? c.white : c.muted }}>{filter}</T>
          </Tap>
        ))}
      </View>

      <LinearGradient colors={["#fff8fa", "#f5f0fc"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0.3 }} style={s.banner}>
        <View style={s.stackSmall}>
          <View style={[s.miniCard, { backgroundColor: c.lavenderSoft, transform: [{ rotate: "-9deg" }, { translateX: -4 }] }]} />
          <View style={[s.miniCard, { backgroundColor: c.pinkSoft, transform: [{ rotate: "8deg" }, { translateX: 4 }] }]} />
          <View style={[s.miniCard, s.miniTop]}><Icon name="book" size={21} color="#a0647d" /></View>
        </View>
        <View style={{ flex: 1 }}>
          <T style={{ ...lbl, marginBottom: 4 }}>YOUR OWN STUDY SET</T>
          <T style={{ fontFamily: f.head, fontSize: 16 }}>{savedDeck || "Create flashcards"}</T>
          <T style={{ color: c.muted, marginTop: 4, lineHeight: 15 }}>{savedDeck ? "Your new set is ready to review." : "Make them yourself or turn notes into cards with AI."}</T>
        </View>
        <Tap style={s.pale} onPress={() => setFlashMode("choose")}><Icon name={savedDeck ? "arrow" : "plus"} size={18} color="#af6880" /></Tap>
      </LinearGradient>

      <LinearGradient colors={["#a99bd0", "#c3b7de"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.featured}>
        <View style={s.ring} />
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
          <Sticker style={{ borderWidth: 0 }}>Recommended for you</Sticker>
          <Icon name="sparkle" color={c.white} />
        </View>
        <T style={s.featuredTitle}>Programming Fundamentals</T>
        <View style={{ flexDirection: "row", gap: 14, marginTop: 10 }}>
          {["20 questions", "15 min", "Medium"].map((m) => <T key={m} style={{ color: "rgba(255,255,255,0.88)", fontSize: 11 }}>{m}</T>)}
        </View>
        <Tap style={s.lightBtn} onPress={() => setInQuiz(true)}>
          <T style={{ color: "#7666a1", fontFamily: f.bodyBold, fontSize: 12 }}>Start practice</T>
          <Icon name="arrow" size={18} color="#7666a1" />
        </Tap>
      </LinearGradient>

      <View style={s.sectionRow}>
        <T style={{ fontFamily: f.head, fontSize: 17 }}>Explore exercises</T>
        <T style={{ color: c.muted, fontSize: 10, fontFamily: f.bodyMedium }}>{filtered.length} sets</T>
      </View>
      <View style={{ gap: 10 }}>
        {filtered.map((card) => {
          const t = tones[card.tone];
          return (
            <Card key={card.title} style={s.practiceCard}>
              <View style={[s.practiceIcon, { backgroundColor: t.bg }]}><Icon name="book" color={t.fg} /></View>
              <View style={{ flex: 1 }}>
                <T style={{ ...lbl, marginBottom: 4 }}>{card.subject.toUpperCase()}</T>
                <T style={{ fontFamily: f.head, fontSize: 16, lineHeight: 19 }}>{card.title}</T>
                <View style={{ flexDirection: "row", gap: 7, marginTop: 7 }}>
                  <T style={s.meta}>{card.questions} questions</T>
                  <T style={s.meta}>{card.time} min</T>
                  <T style={[s.meta, { color: t.fg }]}>● {card.level}</T>
                </View>
              </View>
              <Tap style={s.pale} onPress={() => setInQuiz(true)}><Icon name="arrow" size={18} color="#af6880" /></Tap>
            </Card>
          );
        })}
      </View>
    </View>
  );
}

function Option({ icon, tone, title, note, onPress }: { icon: IconName; tone: Tone; title: string; note: string; onPress: () => void }) {
  const t = tones[tone];
  return (
    <Tap onPress={onPress} style={s.option}>
      <View style={{ width: 48, height: 48, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: t.bg }}>
        <Icon name={icon} color={t.fg} />
      </View>
      <View style={{ flex: 1, gap: 3 }}>
        <T style={{ fontFamily: f.head, fontSize: 14 }}>{title}</T>
        <T style={{ color: c.muted, fontSize: 10 }}>{note}</T>
      </View>
      <Icon name="chevron" size={18} color="#b2a4ab" />
    </Tap>
  );
}

const s = StyleSheet.create({
  search: { flexDirection: "row", alignItems: "center", gap: 10, height: 50, paddingHorizontal: 15, borderWidth: 1, borderColor: c.line, borderRadius: 17, backgroundColor: c.white, ...shadowSmall },
  chip: { paddingVertical: 8, paddingHorizontal: 16, borderRadius: 99, borderWidth: 1, borderColor: c.line, backgroundColor: c.white },
  chipOn: { borderColor: c.pink, backgroundColor: c.pink },
  banner: { flexDirection: "row", alignItems: "center", gap: 13, marginBottom: 14, padding: 15, borderRadius: 22, borderWidth: 1, borderColor: "#eaddeb", ...shadowSmall },
  stackSmall: { width: 52, height: 58, alignItems: "center", justifyContent: "center" },
  miniCard: { position: "absolute", width: 39, height: 48, borderRadius: 9, borderWidth: 1, borderColor: "#dbcfea" },
  miniTop: { backgroundColor: c.white, borderColor: "#e9dce2", alignItems: "center", justifyContent: "center" },
  pale: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", backgroundColor: c.pinkPale },
  featured: { padding: 21, borderRadius: 26, overflow: "hidden", ...shadow },
  ring: { position: "absolute", right: -30, bottom: -45, width: 145, height: 145, borderRadius: 73, borderWidth: 20, borderColor: "rgba(255,255,255,0.09)" },
  featuredTitle: { width: "72%", marginTop: 18, fontFamily: f.head, fontSize: 23, lineHeight: 26, color: c.white },
  lightBtn: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 8, marginTop: 18, paddingVertical: 10, paddingHorizontal: 15, borderRadius: 99, backgroundColor: c.white },
  sectionRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 27, marginBottom: 12, marginHorizontal: 2 },
  practiceCard: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14 },
  practiceIcon: { width: 46, height: 51, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  meta: { color: c.muted, fontSize: 10 },
  close: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: c.line, backgroundColor: c.white },
  flashIntro: { alignItems: "center", paddingVertical: 23, paddingHorizontal: 18, borderRadius: 26, borderWidth: 1, borderColor: "#eaddeb" },
  stackBig: { width: 76, height: 78, marginBottom: 13, alignItems: "center", justifyContent: "center" },
  stackCard: { position: "absolute", width: 54, height: 66, borderRadius: 13, borderWidth: 1, borderColor: "#dbcfea" },
  stackTop: { backgroundColor: c.white, borderColor: "#e9dce2", alignItems: "center", justifyContent: "center" },
  option: { flexDirection: "row", alignItems: "center", gap: 13, paddingVertical: 17, paddingHorizontal: 15, borderWidth: 1, borderColor: c.line, borderRadius: 21, backgroundColor: c.white, ...shadowSmall },
  magicNote: { flexDirection: "row", alignItems: "center", gap: 9, marginTop: 16, padding: 12, paddingHorizontal: 14, borderRadius: 15, backgroundColor: c.sageSoft },
  input: { borderWidth: 1, borderColor: c.line, borderRadius: 16, backgroundColor: c.white, color: c.ink, fontFamily: f.body, fontSize: 13, height: 49, paddingHorizontal: 14 },
  textarea: { height: undefined, minHeight: 105, paddingTop: 14, paddingBottom: 14, textAlignVertical: "top", lineHeight: 19 },
  counter: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 21, marginBottom: 9, marginHorizontal: 2 },
  divider: { flexDirection: "row", alignItems: "center", marginVertical: 12 },
  divLine: { height: 1, flex: 1, backgroundColor: c.line },
  divIcon: { width: 27, height: 27, borderRadius: 14, marginHorizontal: 8, alignItems: "center", justifyContent: "center", backgroundColor: c.pinkPale, transform: [{ rotate: "90deg" }] },
  addAnother: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginTop: 11, padding: 13, borderWidth: 1, borderStyle: "dashed", borderColor: "#dcb7c6", borderRadius: 16 },
  aiHelper: { flexDirection: "row", alignItems: "center", gap: 12, marginVertical: 18, padding: 14, borderRadius: 18, backgroundColor: c.lavenderSoft },
  aiIcon: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.7)" },
  or: { flexDirection: "row", alignItems: "center", gap: 10, marginVertical: 15 },
  upload: { alignItems: "center", padding: 20, borderWidth: 1, borderStyle: "dashed", borderColor: "#cdbfda", borderRadius: 20, backgroundColor: "#fbf8fe" },
  uploadIcon: { width: 39, height: 39, borderRadius: 13, marginBottom: 8, alignItems: "center", justifyContent: "center", backgroundColor: c.lavenderSoft },
  uploadedPill: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 9, paddingVertical: 5, paddingHorizontal: 8, borderRadius: 99, backgroundColor: c.sageSoft },
  genOptions: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 15 },
  count: { width: 35, height: 31, borderRadius: 9, borderWidth: 1, borderColor: c.line, backgroundColor: c.white, alignItems: "center", justifyContent: "center" },
  countOn: { borderColor: c.pink, backgroundColor: c.pinkSoft },
  primary: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, marginTop: 15, padding: 14, borderRadius: 17, backgroundColor: c.pink, shadowColor: c.pink, shadowOpacity: 0.3, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 3 },
  primaryText: { color: c.white, fontFamily: f.bodyBold, fontSize: 13 },
  badge: { paddingVertical: 7, paddingHorizontal: 11, borderRadius: 99, backgroundColor: c.pinkSoft },
  strip: { flexDirection: "row", alignItems: "center", gap: 11, padding: 12, paddingHorizontal: 14, borderRadius: 16, backgroundColor: c.lavenderSoft },
  questionCard: { minHeight: 155, marginTop: 18, marginBottom: 14, padding: 23, justifyContent: "center", borderRadius: 24 },
  question: { marginTop: 8, fontFamily: f.head, fontSize: 23, lineHeight: 29, textAlign: "center" },
  answer: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12, paddingHorizontal: 14, borderWidth: 1, borderColor: c.line, borderRadius: 17, backgroundColor: c.white },
  letter: { width: 30, height: 30, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#f6f1f2" },
  feedback: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 13, padding: 14, borderRadius: 18 },
  feedbackIcon: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.7)" },
});
