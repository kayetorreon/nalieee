import React from "react";
import { StyleSheet, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Card, Header, Icon, Progress, SectionHeading, T, Tap } from "../components";
import { c, f, shadowSmall, tones } from "../theme";

const days = ["M", "T", "W", "T", "F", "S", "S"];

export default function ProgressScreen() {
  return (
    <View>
      <Header eyebrow="YOUR GROWTH GARDEN" title="Look how far you've come!" action={<View style={s.weekPill}><T style={{ color: c.muted, fontSize: 10, fontFamily: f.bodyMedium }}>This week ⌄</T></View>} />

      <LinearGradient colors={["#fbe4ea", "#fff3e8"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.streak}>
        <View style={s.flame}><Icon name="flame" size={34} color="#e38892" /></View>
        <View>
          <T style={{ color: c.muted, fontSize: 11 }}>Current streak</T>
          <T style={{ fontFamily: f.head, fontSize: 29, lineHeight: 34 }}>7 days</T>
          <T style={{ color: c.muted, fontSize: 11 }}>Your longest yet!</T>
        </View>
        <View style={{ position: "absolute", right: 20, top: 18 }}><Icon name="sparkle" color="#e7b28f" /></View>
      </LinearGradient>

      <Card style={s.week}>
        {days.map((d, i) => (
          <View key={i} style={{ alignItems: "center", gap: 7 }}>
            <T style={{ color: c.muted, fontSize: 10 }}>{d}</T>
            <View style={[s.day, i < 6 && s.dayOn]}>
              {i < 6 ? <Icon name="check" size={15} color="#b55f79" /> : <T style={{ color: "#a99ba2", fontSize: 10 }}>21</T>}
            </View>
          </View>
        ))}
      </Card>

      <View style={{ flexDirection: "row", gap: 11, marginTop: 12 }}>
        <Card style={s.insight}>
          <View style={[s.insightIcon, { backgroundColor: tones.pink.bg }]}><Icon name="clock" color={tones.pink.fg} /></View>
          <T style={{ fontFamily: f.head, fontSize: 20 }}>4h 20m</T>
          <T style={{ color: c.muted, fontSize: 10 }}>Study time</T>
          <T style={s.delta}>+32 min</T>
        </Card>
        <Card style={s.insight}>
          <View style={[s.insightIcon, { backgroundColor: tones.lavender.bg }]}><Icon name="sparkle" color={tones.lavender.fg} /></View>
          <T style={{ fontFamily: f.head, fontSize: 20 }}>84%</T>
          <T style={{ color: c.muted, fontSize: 10 }}>Accuracy</T>
          <T style={s.delta}>+6% this week</T>
        </Card>
      </View>

      <View style={s.sectionRow}>
        <T style={{ fontFamily: f.head, fontSize: 17 }}>Weekly study</T>
        <T style={{ color: c.muted, fontSize: 10, fontFamily: f.bodyMedium }}>5h goal</T>
      </View>
      <Card style={s.chart}>
        <View style={{ flex: 1, flexDirection: "row", gap: 12 }}>
          {[38, 62, 48, 76, 54, 88, 28].map((h, i) => (
            <View key={i} style={{ flex: 1, alignItems: "center" }}>
              <View style={{ flex: 1, justifyContent: "flex-end" }}>
                <View style={{ width: 14, height: `${h}%`, minHeight: 8, borderTopLeftRadius: 99, borderTopRightRadius: 99, borderBottomLeftRadius: 5, borderBottomRightRadius: 5, backgroundColor: i === 5 ? c.pink : c.pinkSoft }} />
              </View>
              <T style={{ color: c.muted, fontSize: 9, marginTop: 7 }}>{days[i]}</T>
            </View>
          ))}
        </View>
      </Card>

      <SectionHeading title="Subject garden" action="See details" />
      <Card style={{ paddingVertical: 5, paddingHorizontal: 15 }}>
        {(
          [
            ["Programming", 88, "pink"],
            ["Databases", 74, "lavender"],
            ["Networking", 66, "green"],
          ] as const
        ).map(([name, val, tone], i) => (
          <View key={name} style={[s.subjectRow, i < 2 && { borderBottomWidth: 1, borderStyle: "dashed", borderColor: c.line }]}>
            <View style={[s.badge, { backgroundColor: tones[tone].bg }]}><Icon name="book" size={17} color={tones[tone].fg} /></View>
            <View style={{ flex: 1, gap: 7 }}>
              <T style={{ fontFamily: f.bodyBold, fontSize: 12 }}>{name}</T>
              <View style={{ flexDirection: "row" }}><Progress value={val} tone={tone} /></View>
            </View>
            <T style={{ color: c.muted, fontSize: 11, fontFamily: f.bodyBold, width: 34, textAlign: "right" }}>{val}%</T>
          </View>
        ))}
      </Card>
    </View>
  );
}

const s = StyleSheet.create({
  weekPill: { paddingVertical: 8, paddingHorizontal: 11, borderRadius: 99, borderWidth: 1, borderColor: c.line, backgroundColor: c.white },
  streak: { flexDirection: "row", alignItems: "center", gap: 17, padding: 22, borderRadius: 26, overflow: "hidden" },
  flame: { width: 67, height: 67, borderRadius: 22, alignItems: "center", justifyContent: "center", backgroundColor: c.white, ...shadowSmall },
  week: { flexDirection: "row", justifyContent: "space-between", marginTop: 12, paddingVertical: 14, paddingHorizontal: 10, borderRadius: 20 },
  day: { width: 31, height: 31, borderRadius: 16, borderWidth: 1, borderStyle: "dashed", borderColor: "#d9ced3", alignItems: "center", justifyContent: "center" },
  dayOn: { borderStyle: "solid", borderColor: c.pink, backgroundColor: c.pinkSoft },
  insight: { flex: 1, padding: 15, borderRadius: 20 },
  insightIcon: { width: 35, height: 35, borderRadius: 12, marginBottom: 13, alignItems: "center", justifyContent: "center" },
  delta: { marginTop: 7, color: "#6c9675", fontSize: 9, fontFamily: f.bodyBold },
  sectionRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 27, marginBottom: 12, marginHorizontal: 2 },
  chart: { height: 180, paddingTop: 22, paddingHorizontal: 16, paddingBottom: 14 },
  subjectRow: { flexDirection: "row", alignItems: "center", gap: 11, paddingVertical: 13 },
  badge: { width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center" },
});
