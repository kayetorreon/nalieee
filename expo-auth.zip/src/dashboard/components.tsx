import React, { ReactNode } from "react";
import { Pressable, StyleProp, StyleSheet, Text, TextProps, TextStyle, View, ViewStyle } from "react-native";
import Svg, { Circle, Path, Rect } from "react-native-svg";
import { c, f, shadowSmall, Tone, tones } from "./theme";

export type IconName =
  | "home" | "book" | "check" | "sprout" | "user" | "bell" | "clock" | "sparkle" | "flame"
  | "arrow" | "search" | "calendar" | "target" | "plus" | "chevron" | "settings" | "moon"
  | "heart" | "edit";

type Shape = string | { c: [number, number, number] } | { r: [number, number, number, number, number] };

const shapes: Record<IconName, Shape[]> = {
  home: ["m3 11 9-8 9 8", "M5 10v10h14V10M9 20v-6h6v6"],
  book: ["M4 5.5A3.5 3.5 0 0 1 7.5 2H11v17H7.5A3.5 3.5 0 0 0 4 22Z", "M20 5.5A3.5 3.5 0 0 0 16.5 2H13v17h3.5A3.5 3.5 0 0 1 20 22Z"],
  check: ["m5 12 4 4L19 6"],
  sprout: ["M12 22V10", "M12 13C7 13 4 10 4 5c5 0 8 3 8 8Z", "M12 16c0-5 3-8 8-8 0 5-3 8-8 8Z"],
  user: [{ c: [12, 8, 4] }, "M4 22c0-5 3-8 8-8s8 3 8 8"],
  bell: ["M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9", "M10 21h4"],
  clock: [{ c: [12, 12, 9] }, "M12 7v6l4 2"],
  sparkle: ["m12 2 1.5 5.5L19 9l-5.5 1.5L12 16l-1.5-5.5L5 9l5.5-1.5Z", "m19 16 .7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7Z"],
  flame: ["M13 2c1 5-3 5-1 9 1-2 3-3 4-5 3 3 4 6 3 10a7 7 0 0 1-14 0c0-3 2-6 5-9 0 3 1 4 3 5"],
  arrow: ["M5 12h14", "m14 7 5 5-5 5"],
  search: [{ c: [10, 10, 7] }, "m15 15 6 6"],
  calendar: [{ r: [3, 5, 18, 16, 3] }, "M8 3v4M16 3v4M3 10h18"],
  target: [{ c: [12, 12, 9] }, { c: [12, 12, 5] }, { c: [12, 12, 1] }],
  plus: ["M12 5v14M5 12h14"],
  chevron: ["m9 5 7 7-7 7"],
  settings: [{ c: [12, 12, 3] }, "M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"],
  moon: ["M20 15.5A8.5 8.5 0 0 1 8.5 4 8.5 8.5 0 1 0 20 15.5Z"],
  heart: ["M20.8 5.8a5.5 5.5 0 0 0-7.8 0L12 6.9l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 22l8.8-8.4a5.5 5.5 0 0 0 0-7.8Z"],
  edit: ["m14 4 6 6L9 21H3v-6Z", "m13 5 6 6"],
};

export function Icon({ name, size = 20, color = c.ink }: { name: IconName; size?: number; color?: string }) {
  const common = { stroke: color, strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, fill: "none" };
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      {shapes[name].map((s, i) =>
        typeof s === "string" ? (
          <Path key={i} d={s} {...common} />
        ) : "c" in s ? (
          <Circle key={i} cx={s.c[0]} cy={s.c[1]} r={s.c[2]} {...common} />
        ) : (
          <Rect key={i} x={s.r[0]} y={s.r[1]} width={s.r[2]} height={s.r[3]} rx={s.r[4]} {...common} />
        )
      )}
    </Svg>
  );
}

/** Text with the app's default font + colour. */
export function T({ style, ...rest }: TextProps) {
  return <Text {...rest} style={[{ fontFamily: f.body, color: c.ink, fontSize: 12 }, style]} />;
}

/** Pressable with the small "press" scale animation from the web app. */
export function Tap({ children, style, onPress }: { children?: ReactNode; style?: StyleProp<ViewStyle>; onPress?: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [style, pressed && { transform: [{ scale: 0.97 }] }]}>
      {children}
    </Pressable>
  );
}

export function Header({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: ReactNode }) {
  return (
    <View style={s.header}>
      <View style={{ flex: 1 }}>
        {eyebrow ? <T style={s.eyebrow}>{eyebrow}</T> : null}
        <T style={s.title}>{title}</T>
      </View>
      {action}
    </View>
  );
}

export function IconButton({ icon, onPress }: { icon: IconName; onPress?: () => void }) {
  return (
    <Tap onPress={onPress} style={s.iconButton}>
      <Icon name={icon} />
    </Tap>
  );
}

export function Progress({ value, tone = "pink" }: { value: number; tone?: "pink" | "lavender" | "green" }) {
  const fill = tone === "pink" ? c.pink : tone === "lavender" ? c.lavender : c.sage;
  return (
    <View style={s.progress}>
      <View style={{ height: "100%", borderRadius: 99, backgroundColor: fill, width: `${value}%` }} />
    </View>
  );
}

export function SectionHeading({ title, icon, tone, action, onAction }: { title: string; icon?: IconName; tone?: Tone; action?: string; onAction?: () => void }) {
  const t = tone ? tones[tone] : null;
  return (
    <View style={s.sectionHeading}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
        {icon && t ? (
          <View style={[s.miniIcon, { backgroundColor: t.bg }]}>
            <Icon name={icon} size={17} color={t.fg} />
          </View>
        ) : null}
        <T style={{ fontFamily: f.head, fontSize: 17 }}>{title}</T>
      </View>
      {action ? (
        <Tap onPress={onAction}>
          <T style={{ color: "#ad6880", fontFamily: f.bodyBold, fontSize: 12 }}>{action}</T>
        </Tap>
      ) : null}
    </View>
  );
}

export function Sticker({ children, style }: { children: string; style?: StyleProp<ViewStyle> }) {
  return (
    <View style={[s.sticker, style]}>
      <T style={{ fontFamily: f.hand, fontSize: 15, color: "#a95f79" }}>{children}</T>
    </View>
  );
}

export function Card({ style, children }: { style?: StyleProp<ViewStyle>; children: ReactNode }) {
  return <View style={[s.card, style]}>{children}</View>;
}

export const label: TextStyle = { color: c.muted, fontSize: 10, fontFamily: f.bodyBold, letterSpacing: 1.4 };

export function Mascot({ style }: { style?: StyleProp<ViewStyle> }) {
  const line = "#765e6b";
  return (
    <Svg viewBox="0 0 150 130" style={style}>
      <Path d="M17 113c19-14 96-15 119 0-19 15-102 15-119 0Z" fill="rgba(105,75,91,0.10)" />
      <Path d="m47 45-4-22 20 13c8-4 24-4 33 0l19-13-4 24c8 9 10 21 5 33-7 18-26 26-46 22-22-4-35-18-34-34 0-9 4-17 11-23Z" fill="#fff9ed" stroke={line} strokeWidth={2.2} strokeLinejoin="round" />
      <Path d="m51 31 4 12m51-12-3 12M59 61c4 5 10 5 14 0m14 0c4 5 10 5 14 0" fill="none" stroke={line} strokeWidth={2} strokeLinecap="round" />
      <Path d="m77 66 4 3 4-3" fill="#eba0af" stroke={line} strokeWidth={2} strokeLinecap="round" />
      <Path d="M77 83c-16-9-31-8-43-1l6 32c12-6 25-4 39 4Z" fill="#e99ab2" stroke={line} strokeWidth={2} />
      <Path d="M79 83c16-9 31-8 43-1l-6 32c-12-6-25-4-39 4Z" fill="#b6a8dc" stroke={line} strokeWidth={2} />
      <Path d="m78 86 1 29M45 91c8-3 17-2 25 2m27-2c7-3 12-3 18-1" fill="none" stroke={line} strokeWidth={2} strokeLinecap="round" />
      <Path d="m23 43 3 7 7 3-7 3-3 7-3-7-7-3 7-3Zm103 1 2 5 5 2-5 2-2 5-2-5-5-2 5-2Z" fill="#e69ab2" />
    </Svg>
  );
}

const s = StyleSheet.create({
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 16, marginTop: 8, marginBottom: 22 },
  eyebrow: { ...label, marginBottom: 4 },
  title: { fontFamily: f.head, fontSize: 26, lineHeight: 30, letterSpacing: -0.9 },
  iconButton: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: c.line, backgroundColor: c.white, ...shadowSmall },
  progress: { flex: 1, height: 7, overflow: "hidden", borderRadius: 99, backgroundColor: "#f2ecee" },
  sectionHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 27, marginBottom: 12, marginHorizontal: 2 },
  miniIcon: { width: 29, height: 29, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  sticker: { alignSelf: "flex-start", paddingVertical: 6, paddingHorizontal: 10, borderRadius: 999, borderWidth: 1, borderColor: "rgba(233,143,172,0.28)", backgroundColor: "rgba(255,255,255,0.7)", transform: [{ rotate: "-1deg" }] },
  card: { borderWidth: 1, borderColor: c.line, borderRadius: 22, backgroundColor: c.white, ...shadowSmall },
});
