import { useState } from "react";
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, View } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Icon, IconName, T, Tap } from "./components";
import { c, f } from "./theme";
import type { Tab } from "./types";
import Home from "./screens/Home";
import Practice from "./screens/Practice";
import Tasks from "./screens/Tasks";
import ProgressScreen from "./screens/ProgressScreen";
import Profile from "./screens/Profile";
import { useAuth } from "../context/AuthContext";

const nav: { id: Tab; label: string; icon: IconName }[] = [
  { id: "home", label: "Home", icon: "home" },
  { id: "practice", label: "Practice", icon: "book" },
  { id: "tasks", label: "Tasks", icon: "check" },
  { id: "progress", label: "Progress", icon: "sprout" },
  { id: "profile", label: "Profile", icon: "user" },
];

export default function Shell() {
  const [tab, setTab] = useState<Tab>("home");
  const { signOut } = useAuth();
  const insets = useSafeAreaInsets();
  return (
    <View style={{ flex: 1, backgroundColor: c.cream }}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView
          key={tab}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingTop: insets.top + 16, paddingHorizontal: 20, paddingBottom: 112 + insets.bottom }}
        >
          {tab === "home" && <Home go={setTab} />}
          {tab === "practice" && <Practice />}
          {tab === "tasks" && <Tasks />}
          {tab === "progress" && <ProgressScreen />}
          {tab === "profile" && <Profile onSignOut={signOut} />}
        </ScrollView>
      </KeyboardAvoidingView>

      <View style={[s.nav, { bottom: 14 + insets.bottom / 2 }]}>
        {nav.map((item) => {
          const on = tab === item.id;
          return (
            <Tap key={item.id} style={s.item} onPress={() => setTab(item.id)}>
              <View style={[s.navIcon, on && { backgroundColor: c.pinkSoft }]}>
                <Icon name={item.icon} color={on ? "#b55f79" : "#a798a0"} />
              </View>
              <T style={{ fontSize: 10, fontFamily: f.bodyBold, color: on ? "#b55f79" : "#a798a0" }}>{item.label}</T>
            </Tap>
          );
        })}
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  nav: { position: "absolute", left: 12, right: 12, height: 76, flexDirection: "row", paddingVertical: 8, paddingHorizontal: 10, borderRadius: 25, borderWidth: 1, borderColor: "rgba(232,220,222,0.85)", backgroundColor: "rgba(255,253,249,0.96)", shadowColor: "#523946", shadowOpacity: 0.16, shadowRadius: 18, shadowOffset: { width: 0, height: 8 }, elevation: 8 },
  item: { flex: 1, alignItems: "center", justifyContent: "center", gap: 4 },
  navIcon: { width: 38, height: 36, borderRadius: 14, alignItems: "center", justifyContent: "center" },
});
