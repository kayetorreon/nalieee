// Re-export the app theme using the short aliases that the dashboard screens expect.
import { colors, fonts, shadow, shadowSmall } from "../theme";

// The dashboard screens import `c`, `f`, etc. from "../theme" (relative to dashboard/).
// This file maps the expo-auth theme tokens to those short names.

export const c = {
  ...colors,
  // aliases the dashboard screens use that aren't in the auth theme
  paper: colors.paper ?? "#fffdf9",
  blueSoft: "#e4f1f4",
};

export const f = {
  body: fonts.body,
  bodyMedium: fonts.bodyMedium,
  bodyBold: fonts.bodyBold,
  head: fonts.heading,
  headMid: fonts.headingSemi,
  hand: fonts.hand,
};

export { shadow, shadowSmall };

export type Tone = "pink" | "lavender" | "green" | "peach" | "blue" | "neutral";
export const tones: Record<Tone, { bg: string; fg: string }> = {
  pink: { bg: c.pinkSoft, fg: "#b8627c" },
  lavender: { bg: c.lavenderSoft, fg: "#7768a2" },
  green: { bg: c.sageSoft, fg: "#648e6e" },
  peach: { bg: c.peachSoft, fg: "#b87456" },
  blue: { bg: c.blueSoft, fg: "#608b96" },
  neutral: { bg: "#f1eded", fg: "#817279" },
};
