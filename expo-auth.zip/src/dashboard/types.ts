export type Tab = "home" | "practice" | "tasks" | "progress" | "profile";
