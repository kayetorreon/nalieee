import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  updateProfile,
  type User,
} from "firebase/auth";
import { auth, isFirebaseConfigured } from "../../firebase";

type AuthContextValue = {
  user: User | null;
  initializing: boolean; // true until Firebase restores the saved session
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (name: string, email: string, password: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

// Turns Firebase error codes into messages that are safe to show to the user.
export function friendlyAuthError(error: unknown): string {
  const code = (error as { code?: string })?.code ?? "";
  switch (code) {
    case "auth/invalid-email": return "That email address doesn't look right.";
    case "auth/user-not-found":
    case "auth/wrong-password":
    case "auth/invalid-credential": return "Email or password is incorrect.";
    case "auth/email-already-in-use": return "An account with this email already exists.";
    case "auth/weak-password": return "Please choose a stronger password (at least 6 characters).";
    case "auth/too-many-requests": return "Too many attempts. Please wait a moment and try again.";
    case "auth/network-request-failed": return "No connection. Check your internet and try again.";
    case "auth/user-disabled": return "This account has been disabled.";
    case "auth/api-key-not-valid":
    case "auth/invalid-api-key": return "Firebase API key is invalid. Please check your .env file.";
    default: return (error as Error)?.message || "Something went wrong. Please try again.";
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [initializing, setInitializing] = useState(true);
  const [version, setVersion] = useState(0); // bumps when the profile changes in place

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (next) => {
      setUser(next);
      setInitializing(false);
    });
    return unsubscribe;
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      initializing,
      signIn: async (email, password) => {
        if (!isFirebaseConfigured) {
          throw new Error("Firebase is not configured. Add your Firebase credentials to the .env file.");
        }
        await signInWithEmailAndPassword(auth, email.trim(), password);
      },
      signUp: async (name, email, password) => {
        if (!isFirebaseConfigured) {
          throw new Error("Firebase is not configured. Add your Firebase credentials to the .env file.");
        }
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await updateProfile(cred.user, { displayName: name.trim() });
        // The User object is mutated in place, so bump a counter to re-render consumers.
        setVersion((v) => v + 1);
      },
      resetPassword: async (email) => {
        if (!isFirebaseConfigured) {
          throw new Error("Firebase is not configured. Add your Firebase credentials to the .env file.");
        }
        await sendPasswordResetEmail(auth, email.trim());
      },
      signOut: () => firebaseSignOut(auth),
    }),
    [user, initializing, version]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}
